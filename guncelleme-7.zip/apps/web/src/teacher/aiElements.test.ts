import { describe, it, expect } from "vitest";
import type { Op } from "@edershane/board-player";
import { AiElements, frameFor, partial } from "./aiElements";

const line = (extra: object = {}): Op => ({ cmdId: "c", start: 1000, dur: 1000, kind: "path", pts: [{ x: 0, y: 0 }, { x: 100, y: 0 }], color: "blue", ...extra } as Op);
const text = (extra: object = {}): Op => ({ cmdId: "c", start: 0, dur: 1000, kind: "text", text: "ABCD", box: { x: 10, y: 20, w: 50, h: 24 }, size: 22, color: "ink", ...extra } as Op);

describe("frameFor", () => {
  it("başlamadan nesne yok; ortasında çizginin yarısı; sonunda tamam", () => {
    expect(frameFor(line(), 500).skel).toBeNull();
    const mid = frameFor(line(), 1500);
    expect(mid.complete).toBe(false);
    expect(mid.skel!.type).toBe("line");
    expect(mid.skel!.points).toEqual([[0, 0], [50, 0]]);   // ease(0.5) = 0.5
    const end = frameFor(line(), 2500);
    expect(end.complete).toBe(true);
    expect(end.skel!.points[1]).toEqual([100, 0]);
  });
  it("kesikli, ok başlı, saydam ve geometri için pürüzsüz (roughness 0)", () => {
    const f = frameFor(line({ dashed: true, arrowHead: true, alpha: 0.35, width: 9 }), 2500).skel!;
    expect(f.strokeStyle).toBe("dashed"); expect(f.type).toBe("arrow"); expect(f.endArrowhead).toBe("arrow");
    expect(f.opacity).toBe(35); expect(f.strokeWidth).toBe(9); expect(f.roughness).toBe(0);
  });
  it("çok noktalı çizgide ilk parçalar tam, sonuncusu kısmi", () => {
    const pts = partial([{ x: 0, y: 0 }, { x: 10, y: 0 }, { x: 10, y: 10 }], 0.75);   // toplam 20, 15'i çiz
    expect(pts).toEqual([{ x: 0, y: 0 }, { x: 10, y: 0 }, { x: 10, y: 5 }]);
  });
  it("yazı harf harf büyür, el yazısı fontuyla", () => {
    expect(frameFor(text(), 0).skel).toBeNull();
    expect(frameFor(text(), 500).skel!.text).toBe("AB");
    const full = frameFor(text(), 1000);
    expect(full.skel!.text).toBe("ABCD"); expect(full.complete).toBe(true);
    expect(full.skel!.fontFamily).toBe(1);
  });
  it("halka yay olarak çizilir; lazer nesne olmaz", () => {
    const ring: Op = { cmdId: "r", start: 0, dur: 400, kind: "ring", at: { x: 50, y: 50 }, r: 14, color: "red" } as Op;
    expect(frameFor(ring, 200).skel!.points.length).toBeGreaterThan(2);
    expect(frameFor(ring, 400).skel!.points.length).toBe(33);
    expect(frameFor({ cmdId: "l", start: 0, dur: 1000, kind: "laser", at: { x: 1, y: 1 } } as Op, 500).skel).toBeNull();
  });
});

// sahte Excalidraw
function stub() {
  let scene: any[] = []; let updates = 0;
  const api = { getSceneElements: () => scene, updateScene: ({ elements }: any) => { scene = elements; updates++; } };
  const convert = (sk: any[]) => sk.map((s) => ({ ...s, version: 1, seed: 7 }));
  return { api, convert, get scene() { return scene; }, set scene(v) { scene = v; }, get updates() { return updates; } };
}

describe("AiElements köprüsü", () => {
  it("nesne oluşturur, animasyon boyunca günceller, bitince bırakır", () => {
    const s = stub(); const br = new AiElements(s.api, s.convert, undefined, 0);
    const ops = [line()];
    br.tick(ops, 1500); expect(s.scene.length).toBe(1); expect(s.scene[0].points[1]).toEqual([50, 0]);
    br.tick(ops, 1800); expect(s.scene.length).toBe(1); expect(s.scene[0].points[1][0]).toBeGreaterThan(50);
    br.tick(ops, 2500); expect(s.scene[0].points[1]).toEqual([100, 0]);
    const n = s.updates; br.tick(ops, 3000); expect(s.updates).toBe(n);           // tamamlanan nesneye artık dokunulmaz
  });
  it("öğrencinin taşıdığı nesneyi ezmez, sildiği nesneyi geri eklemez", () => {
    const s = stub(); const br = new AiElements(s.api, s.convert, undefined, 0);
    const ops = [line(), line({ start: 0 })];
    br.tick(ops, 2500);
    expect(s.scene.length).toBe(2);
    s.scene = s.scene.map((e, i) => (i === 0 ? { ...e, x: 999 } : e));              // öğrenci taşıdı
    s.scene = s.scene.slice(0, 1);                                                    // ve ikincisini sildi
    br.tick(ops, 4000);
    expect(s.scene.length).toBe(1); expect(s.scene[0].x).toBe(999);
  });
  it("silinen çizim solarak kaybolur (isDeleted), taşınmış olsa da konumu korunur", () => {
    const s = stub(); const br = new AiElements(s.api, s.convert, undefined, 0);
    const op = line();
    br.tick([op], 2500);
    s.scene = s.scene.map((e) => ({ ...e, x: 500 }));
    op.end = 3000;
    br.tick([op], 3150); expect(s.scene[0].opacity).toBe(50); expect(s.scene[0].x).toBe(500);
    br.tick([op], 3400); expect(s.scene[0].isDeleted).toBe(true);
  });
  it("saat duraklatılınca (araya girme) sahne güncellenmez", () => {
    const s = stub(); const br = new AiElements(s.api, s.convert, undefined, 0);
    const ops = [line()];
    br.tick(ops, 1500); const n = s.updates;
    br.tick(ops, 1500); br.tick(ops, 1500);
    expect(s.updates).toBe(n);
  });
  it("hiç çizilmeden silinen işlem nesne oluşturmaz", () => {
    const s = stub(); const br = new AiElements(s.api, s.convert, undefined, 0);
    const op = line({ start: 100 }); op.end = 50;
    br.tick([op], 200); expect(s.scene.length).toBe(0);
  });
  it("Excalidraw hata verirse tick hata fırlatır (çağıran tuval çizimine döner)", () => {
    const s = stub(); const br = new AiElements(s.api, () => { throw new Error("bozuk sürüm"); }, undefined, 0);
    let err = ""; try { br.tick([line()], 1500); } catch (e) { err = (e as Error).message; }
    expect(err).toBe("bozuk sürüm");
  });
  it("geri alma geçmişine girmemesi için captureUpdate iletilir", () => {
    let got: any; const api = { getSceneElements: () => [], updateScene: (o: any) => { got = o; } };
    const br = new AiElements(api, (s) => s.map((x) => ({ ...x, version: 1 })), "NEVER", 0);
    br.tick([line()], 1500); expect(got.captureUpdate).toBe("NEVER");
  });
});
