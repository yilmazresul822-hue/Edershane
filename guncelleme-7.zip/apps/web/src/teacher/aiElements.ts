import type { Op } from "@edershane/board-player";

/** Öğretmenin çizimlerini Excalidraw'ın kendi nesneleri olarak sahneye ekler: öğrenci taşıyabilir, değiştirebilir, silebilir. */
const COLORS: Record<string, string> = { ink: "#1b1f3b", yellow: "#ffd400", green: "#2fbf71", red: "#e5484d", blue: "#2f6fed" };
const clamp = (v: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));
const ease = (p: number) => (p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);

type V = { x: number; y: number };
export type Skeleton = Record<string, any>;
export type Frame = { skel: Skeleton | null; complete: boolean };

/** Çoklu çizginin ilk `frac` kısmı (uzunluğa göre). */
export function partial(pts: V[], frac: number): V[] {
  const lens = pts.slice(1).map((q, i) => Math.hypot(q.x - pts[i].x, q.y - pts[i].y));
  let remain = lens.reduce((a, b) => a + b, 0) * clamp(frac);
  const out: V[] = [pts[0]];
  for (let i = 0; i < lens.length; i++) {
    const a = pts[i], b = pts[i + 1];
    if (remain >= lens[i]) { out.push(b); remain -= lens[i]; }
    else { const f = lens[i] ? remain / lens[i] : 0; out.push({ x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f }); break; }
  }
  return out;
}

const circlePts = (c: V, r: number): V[] =>
  Array.from({ length: 33 }, (_, i) => { const a = -Math.PI / 2 + (i / 32) * Math.PI * 2; return { x: c.x + Math.cos(a) * r, y: c.y + Math.sin(a) * r }; });

/** Bir işlemin t anındaki Excalidraw nesnesi (iskelet). Silme/solma burada değil, köprüde. */
export function frameFor(op: Op, t: number): Frame {
  if (op.kind === "laser" || t < op.start) return { skel: null, complete: false };
  const raw = (t - op.start) / op.dur, p = clamp(raw), complete = raw >= 1;
  const color = COLORS[op.color] ?? COLORS.ink;

  if (op.kind === "path") {
    const out = partial(op.pts, ease(p));
    if (p <= 0 || out.length < 2) return { skel: null, complete: false };
    const o = out[0];
    const skel: Skeleton = {
      type: op.arrowHead ? "arrow" : "line", x: o.x, y: o.y, points: out.map((q) => [q.x - o.x, q.y - o.y]),
      strokeColor: color, strokeWidth: op.width ?? 3, strokeStyle: op.dashed ? "dashed" : "solid", roughness: 0,
      opacity: Math.round((op.alpha ?? 1) * 100), backgroundColor: "transparent",
    };
    if (op.arrowHead) { skel.endArrowhead = "arrow"; skel.startArrowhead = null; }
    return { skel, complete };
  }
  if (op.kind === "text") {
    const n = Math.ceil(op.text.length * p);
    if (n <= 0) return { skel: null, complete: false };
    return { skel: { type: "text", x: op.box.x, y: op.box.y, text: op.text.slice(0, n), fontSize: op.size, fontFamily: 1, strokeColor: color, opacity: 100, textAlign: "left", verticalAlign: "top" }, complete };
  }
  // ring: daire yayı çizgi olarak
  const all = circlePts(op.at, op.r);
  const cnt = Math.max(2, Math.ceil(p * 32) + 1);
  if (p <= 0) return { skel: null, complete: false };
  const o = all[0], pts = all.slice(0, cnt);
  return { skel: { type: "line", x: o.x, y: o.y, points: pts.map((q) => [q.x - o.x, q.y - o.y]), strokeColor: color, strokeWidth: 4, roughness: 0, opacity: 100, backgroundColor: "transparent" }, complete };
}

type St = { phase: "draw" | "idle" | "gone"; base: number };
const bump = (e: any, patch: Record<string, any>) => ({ ...e, ...patch, version: (e.version ?? 1) + 1, versionNonce: (Math.random() * 2 ** 31) | 0 });

export class AiElements {
  private ids = new WeakMap<object, string>();
  private st = new Map<string, St>();
  private n = 0;
  private lastT = -1;
  private lastLen = -1;
  private lastRun = -1e9;
  /** api: Excalidraw API, convert: convertToExcalidrawElements, never: CaptureUpdateAction.NEVER (geri alma geçmişine girmesin) */
  constructor(private api: any, private convert: (s: any[]) => any[], private never?: any, private minGapMs = 30) {}

  private idOf(op: object) {
    let id = this.ids.get(op);
    if (!id) { id = `ai${Date.now().toString(36)}_${++this.n}`; this.ids.set(op, id); }
    return id;
  }

  /** Her animasyon karesinde çağrılır; hata fırlatırsa çağıran tuval çizimine döner. */
  tick(ops: Op[], t: number, now = performance.now()) {
    if (t === this.lastT && ops.length === this.lastLen) return;
    if (now - this.lastRun < this.minGapMs) return;
    this.lastT = t; this.lastLen = ops.length; this.lastRun = now;

    const scene: any[] = this.api.getSceneElements();
    const byId = new Map(scene.map((e) => [e.id, e]));
    const up = new Map<string, any>();
    const gone = new Set<string>();

    for (const op of ops) {
      if (op.kind === "laser") continue;
      const id = this.idOf(op);
      const st = this.st.get(id);
      if (st?.phase === "gone") continue;

      if (op.end !== undefined && t >= op.end) {        // silindi: solarak kaybolur
        if (!st) { this.st.set(id, { phase: "gone", base: 100 }); continue; }
        const cur = byId.get(id);
        const f = clamp(1 - (t - op.end) / 300);
        st.phase = f <= 0 || !cur ? "gone" : st.phase;
        if (cur && f <= 0) gone.add(id);
        else if (cur) up.set(id, bump(cur, { opacity: Math.round(st.base * f) }));
        continue;
      }
      if (st?.phase === "idle") continue;                 // tamamlandı: artık öğrencinindir, dokunma

      const { skel, complete } = frameFor(op, t);
      if (!skel) continue;
      if (st && !byId.has(id)) { st.phase = "gone"; continue; }   // öğrenci sildi: geri ekleme
      const [el] = this.convert([{ ...skel, id }]);
      const cur = byId.get(id);
      up.set(id, cur ? bump(el, { version: (cur.version ?? 1) + 1, seed: cur.seed ?? el.seed }) : el);
      this.st.set(id, { phase: complete ? "idle" : "draw", base: Number(skel.opacity ?? 100) });
    }
    if (!up.size && !gone.size) return;

    const out = scene.map((e) => (gone.has(e.id) ? bump(e, { isDeleted: true }) : up.get(e.id) ?? e));
    for (const [id, e] of up) if (!byId.has(id)) out.push(e);
    this.api.updateScene({ elements: out, ...(this.never !== undefined ? { captureUpdate: this.never } : {}) });
  }
}
